A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/mJVrjN.

 Created for http://css-snippets.com/simple-horizontal-navigation/

Exploring two different methods for making the navigation horizontal on large screens. The snippet is responsive. It is a vertical menu on smaller screens and a horizontal menu on larger screens.


Forked from [Lisa Catalano](http://codepen.io/lisa_c/)'s Pen [Simple Responsive Horizontal Navigation ](http://codepen.io/lisa_c/pen/akjiy/).

Forked from [Lisa Catalano](http://codepen.io/lisa_c/)'s Pen [Simple Responsive Horizontal Navigation ](http://codepen.io/lisa_c/pen/akjiy/).

Forked from [Lisa Catalano](http://codepen.io/lisa_c/)'s Pen [Simple Responsive Horizontal Navigation ](http://codepen.io/lisa_c/pen/akjiy/).